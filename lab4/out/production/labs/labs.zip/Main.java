import KI35.Hotsii.Lab3.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Main {
    private final static String FILE_PATH = "text.txt";

    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        PrintWriter writer = new PrintWriter(FILE_PATH);
        System.out.print("Enter the matrix size: ");
        int size = scanner.nextInt();
        System.out.print("Enter the placeholder character: ");
        char character = getPlaceholderCharacter();
        char second = 'd';
        int half = size / 2;
        char[][] arr = new char[size][half];


        StringBuilder builder = new StringBuilder();

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                char mainChar = j == 0 || j == half - 1 ? second : character;
                if (j < half) arr[i][j] = mainChar;
                if (i < half && j >= half || i >= half && j < half)
                    builder.append(String.format("%c\t",
                            j == 0 || j == half - 1 || j == half || j == size - 1 ? 'd' : 'a'));
                else
                    builder.append(" \t");
            }
            builder.append("\n");
        }

        writer.write(builder.toString());
        System.out.println(builder);
        System.out.println(Arrays.deepToString(arr));
        writer.close();
        scanner.close();
    }

    private static char getPlaceholderCharacter() {
        Scanner scanner = new Scanner(System.in);
        String character = scanner.nextLine();
        if (character.length() != 1) {
            throw new IllegalArgumentException("Only one character must be entered");
        }
        return character.charAt(0);
    }
/*    public static void main(String[] args) throws IOException {
*//*        Monitor monitor = new Monitor();
        Display display = new Display();
        display.setResolution(Resolution.R1400x1050);
        display.setScale(100);
        Corps corps = new Corps();
        corps.setDiagonalInInches(35);
        corps.setMaterial("iron");
        Controller controller = new Controller();
        controller.setAvailableLVDS(true);
        controller.setHeight(124);
        controller.setWidth(60);
        controller.setVoltage(16);
        monitor.addAdditionalDisplay(display);
        monitor.setController(controller);
        monitor.setCorps(corps);
        monitor.setManufacturer("Apple");
        monitor.removeAdditionalDisplay(display);
        monitor.dispose();*//*

        Display display1 = new Display();
        display1.setResolution(Resolution.R1400x1050);
        Display display2 = new Display();
        display2.setResolution(Resolution.R1440x900);
        Display display3 = new Display();
        display3.setResolution(Resolution.R1600x900);
        Display display4 = new Display();
        display4.setResolution(Resolution.R1920x1080);
        Display display5 = new Display();
        display5.setResolution(Resolution.R1680x1059);

        System.out.println(Display.highestResolution);
    }*/
}
