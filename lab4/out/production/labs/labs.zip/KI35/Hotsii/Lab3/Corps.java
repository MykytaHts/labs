package KI35.Hotsii.Lab3;

import static utils.Validator.*;

public class Corps {
    private String material;
    private int diagonalInInches;

    public Corps() {
        this.material = "plastic";
        this.diagonalInInches = 20;
    }

    public Corps(int width, int height, String material, int diagonalInInches) {
        validateRange(diagonalInInches);
        this.material = material;
        this.diagonalInInches = diagonalInInches;
    }

    public String getMaterial() {
        return material;
    }

    public int getDiagonalInInches() {
        return diagonalInInches;
    }

    public void setDiagonalInInches(int diagonalInInches) {
        validateRange(diagonalInInches);
        this.diagonalInInches = diagonalInInches;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    @Override
    public String toString() {
        return "Corps{" +
                "material='" + material + '\'' +
                ", diagonalInInches=" + diagonalInInches +
                '}';
    }
}
