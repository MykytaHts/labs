package KI35.Hotsii.Lab3;

import java.util.Objects;

import static KI35.Hotsii.Lab3.Resolution.*;
import static utils.Validator.*;

public class Display {
    private Resolution resolution;
    private int scaleInPercent;
    public static Resolution highestResolution = R1400x1050;

    public Display() {
        this.resolution = R1400x1050;
        this.scaleInPercent = 125;
    }

    public Display(Resolution resolution, int scaleInPercent) {
        this.resolution = resolution;
        this.scaleInPercent = scaleInPercent;
    }

    public Resolution getResolution() {
        return resolution;
    }

    public int getScale() {
        return scaleInPercent;
    }

    public void setResolution(Resolution resolution) {
        this.resolution = resolution;
        if (resolution.ordinal() <= highestResolution.ordinal()) {
            highestResolution = resolution;
        }
    }

    public static Resolution getHighestResolution() {
        return highestResolution;
    }

    public void setScale(int scaleInPercent) {
        validateRange(scaleInPercent);
        this.scaleInPercent = scaleInPercent;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Display)) return false;
        Display display = (Display) o;
        return scaleInPercent == display.scaleInPercent &&
                resolution == display.resolution;
    }

    @Override
    public int hashCode() {
        return Objects.hash(resolution, scaleInPercent);
    }

    @Override
    public String toString() {
        return "Display{" +
                "resolution=" + resolution +
                ", scaleInPercent=" + scaleInPercent +
                '}';
    }

    public Display compare(Display display) {
        return resolution.ordinal() < display.resolution.ordinal() ? this : display;
    }
}
