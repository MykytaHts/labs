package KI35.Hotsii.Lab3;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static utils.Helper.getWriter;
import static utils.Validator.validateObjectValues;
import static utils.Validator.validateStringValue;

public class Monitor {
    private Controller controller;
    private Corps corps;
    private String manufacturer;
    private Display mainDisplay;
    private final List<Display> additionalDisplays = new ArrayList<>();
    private final PrintWriter fileWriter = getWriter("text.txt");

    public Monitor() {
        this.controller = new Controller();
        this.mainDisplay = new Display();
        this.corps = new Corps();
        this.manufacturer = "Sumsung";
        fileWriter.printf("Monitor is created. %n{%n%s%n}%n%n", this);
    }

    public Monitor(Controller controller, Display mainDisplay, Corps corps, String manufacturer) {
        validateStringValue(manufacturer);
        this.controller = controller;
        this.mainDisplay = mainDisplay;
        this.corps = corps;
        this.manufacturer = manufacturer;
        fileWriter.printf("Monitor is created. %n{%n%s%n}%n%n", this);
    }

    public Controller getController() {
        return controller;
    }

    public Display getMainDisplay() {
        return mainDisplay;
    }

    public Corps getCorps() {
        return corps;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public List<Display> getAdditionalDisplays() {
        return Collections.unmodifiableList(additionalDisplays);
    }

    public void addAdditionalDisplay(Display display) {
        validateObjectValues(display);
        if (display == mainDisplay)
            throw new IllegalArgumentException("This display is already set as the main display");
        additionalDisplays.add(display);
        fileWriter.printf("Added additional display. %n{%n%s%n}%n%n", display);
    }

    public void removeAdditionalDisplay(Display display) {
        validateObjectValues(display);
        additionalDisplays.remove(display);
        fileWriter.printf("Deleted additional display. %n{%n%s%n}%n%n", display);
    }

    public void setController(Controller controller) {
        validateObjectValues(controller);
        this.controller = controller;
        fileWriter.printf("The controller has been changed. %n{%n%s%n}%n%n", controller);
    }

    public void setMainDisplay(Display mainDisplay) {
        validateObjectValues(mainDisplay);
        if (additionalDisplays.contains(mainDisplay))
            throw new IllegalArgumentException("This display is already set as the additional display");
        this.mainDisplay = mainDisplay;
        fileWriter.printf("The main display has been changed. %n{%n%s%n}%n%n", mainDisplay);
    }

    public void setCorps(Corps corps) {
        validateObjectValues(corps);
        this.corps = corps;
        fileWriter.printf("The corps has been changed. %n{%n%s%n}%n%n", corps);
    }

    public void setManufacturer(String manufacturer) {
        validateStringValue(manufacturer);
        this.manufacturer = manufacturer;
        fileWriter.printf("The manufacturer has been changed. %n{%n%s%n}%n%n", manufacturer);
    }

    public void dispose()
    {
        fileWriter.close();
    }

    @Override
    public String toString() {
        return "Monitor{" +
                "controller=" + controller +
                ", corps=" + corps +
                ", manufacturer='" + manufacturer + '\'' +
                ", mainDisplay=" + mainDisplay +
                ", additionalDisplays=" + additionalDisplays +
                ", fileWriter=" + fileWriter +
                '}';
    }
}
