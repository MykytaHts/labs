package KI35.Hotsii.Lab3;

import static utils.Validator.validateRange;

public class Controller {
    private int voltage;
    private int width;
    private int height;
    private boolean availableLVDS;

    public Controller() {
        this.availableLVDS = true;
        this.width = 140;
        this.height = 60;
        this.voltage = 12;
    }

    public Controller(int width, int height, int voltage) {
        validateRange(width, height, voltage);
        this.width = width;
        this.height = height;
        this.voltage = voltage;
    }

    public void setVoltage(int voltage) {
        validateRange(voltage);
        this.voltage = voltage;
    }

    public void setWidth(int width) {
        validateRange(voltage);
        this.width = width;
    }

    public void setHeight(int height) {
        validateRange(voltage);
        this.height = height;
    }

    public void setAvailableLVDS(boolean availableLVDS) {
        this.availableLVDS = availableLVDS;
    }

    public int getVoltage() {
        return voltage;
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public boolean isAvailableLVDS() {
        return availableLVDS;
    }

    @Override
    public String toString() {
        return "Controller{" +
                "voltage=" + voltage +
                ", width=" + width +
                ", height=" + height +
                ", availableLVDS=" + availableLVDS +
                '}';
    }
}
